import UIKit

var count = 0

for character in "numberOfVowels" {
    switch character {
    case "a", "e", "i", "o", "u":
        count += 1
    default:
        continue
    }
}

print(count)
